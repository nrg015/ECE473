#include "defs.h"
#include "buffer.h"
#include "command.h"
int files_function(){
return 0;
}
