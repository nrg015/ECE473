#include "defs.h"
#include "buffer.h"
int display_function(){
return 0;
}
